/****************************************************************************
** Meta object code from reading C++ file 'AG1graphic.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AG1graphic.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AG1graphic.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AG1graphic_t {
    QByteArrayData data[9];
    char stringdata0[65];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AG1graphic_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AG1graphic_t qt_meta_stringdata_AG1graphic = {
    {
QT_MOC_LITERAL(0, 0, 10), // "AG1graphic"
QT_MOC_LITERAL(1, 11, 9), // "SetAValue"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 1), // "a"
QT_MOC_LITERAL(4, 24, 9), // "SetBValue"
QT_MOC_LITERAL(5, 34, 1), // "b"
QT_MOC_LITERAL(6, 36, 16), // "ChangeResolution"
QT_MOC_LITERAL(7, 53, 1), // "i"
QT_MOC_LITERAL(8, 55, 9) // "SaveImage"

    },
    "AG1graphic\0SetAValue\0\0a\0SetBValue\0b\0"
    "ChangeResolution\0i\0SaveImage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AG1graphic[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x0a /* Public */,
       4,    1,   37,    2, 0x0a /* Public */,
       6,    1,   40,    2, 0x0a /* Public */,
       8,    0,   43,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,

       0        // eod
};

void AG1graphic::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AG1graphic *_t = static_cast<AG1graphic *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SetAValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->SetBValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->ChangeResolution((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->SaveImage(); break;
        default: ;
        }
    }
}

const QMetaObject AG1graphic::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_AG1graphic.data,
      qt_meta_data_AG1graphic,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *AG1graphic::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AG1graphic::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AG1graphic.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int AG1graphic::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
